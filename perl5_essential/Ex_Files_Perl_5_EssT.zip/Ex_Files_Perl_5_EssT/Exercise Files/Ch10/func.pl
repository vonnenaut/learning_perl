#!/usr/bin/perl
# func.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;

func();

sub func {
    say 'This is a wonderful function.';
}
