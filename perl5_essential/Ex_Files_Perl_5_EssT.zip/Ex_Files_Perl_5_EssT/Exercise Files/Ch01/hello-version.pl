#!/usr/bin/perl
# hello-version.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;

say "Perl version is $^V";
