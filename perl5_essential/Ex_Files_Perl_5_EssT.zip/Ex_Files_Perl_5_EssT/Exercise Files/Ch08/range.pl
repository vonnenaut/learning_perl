#!/usr/bin/perl
# range.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;

foreach my $i (1 .. 10) {
    print "$i ";
}
print "\n";
