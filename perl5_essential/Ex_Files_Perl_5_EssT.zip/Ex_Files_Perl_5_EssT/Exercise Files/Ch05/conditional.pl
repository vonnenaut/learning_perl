#!/usr/bin/perl
# conditional.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;

my $x = 1;
my $y = 1;

if ( $x == 1 ) {
    say 'true';
}

say "x is $x; y is $y";
